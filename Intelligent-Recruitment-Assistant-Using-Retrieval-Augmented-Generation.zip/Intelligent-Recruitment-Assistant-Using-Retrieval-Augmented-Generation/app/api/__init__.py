"""
FastAPI Backend Application Package
"""
