from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.api.routes import resumes, matching, chat
from app.core.vector_store import VectorStoreManager

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="MSc Data Science RAG-Powered Intelligent Recruitment Assistant API"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(resumes.router, prefix="/api/v1")
app.include_router(matching.router, prefix="/api/v1")
app.include_router(chat.router, prefix="/api/v1")

@app.get("/")
async def root():
    return {
        "title": settings.APP_NAME,
        "version": settings.VERSION,
        "status": "online",
        "docs_url": "/docs",
        "redoc_url": "/redoc"
    }

@app.get("/health")
async def health_check():
    vector_store = VectorStoreManager()
    indexed_count = vector_store.collection.count()
    return {
        "status": "healthy",
        "vector_db_connected": True,
        "total_resumes_indexed": indexed_count,
        "embedding_provider": settings.EMBEDDING_PROVIDER
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.api.main:app", host=settings.HOST, port=settings.PORT, reload=settings.DEBUG)
