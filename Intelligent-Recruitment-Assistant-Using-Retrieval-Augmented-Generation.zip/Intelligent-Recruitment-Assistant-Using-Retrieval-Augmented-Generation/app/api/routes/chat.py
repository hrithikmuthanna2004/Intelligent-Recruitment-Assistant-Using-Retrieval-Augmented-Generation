from typing import Dict, Any
from pydantic import BaseModel, Field
from fastapi import APIRouter, HTTPException, status
from app.core.rag_engine import RAGEngine

router = APIRouter(prefix="/chat", tags=["Recruiter Chatbot"])
rag_engine = RAGEngine()

class ChatQueryRequest(BaseModel):
    query: str = Field(..., description="Natural language question from recruiter")
    top_k: int = Field(default=4, ge=1, le=20)

@router.post("/query")
async def chat_query(req: ChatQueryRequest) -> Dict[str, Any]:
    """Conversational RAG endpoint for recruiter queries."""
    if not req.query.strip():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Query string cannot be empty.")
    
    response = rag_engine.answer_query(query=req.query, top_k=req.top_k)
    return response
