from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, HTTPException, status
from app.core.ranker import CandidateRanker
from app.core.rag_engine import RAGEngine

router = APIRouter(prefix="/matching", tags=["Matching & Ranking"])
ranker = CandidateRanker()
rag_engine = RAGEngine()

class RankRequest(BaseModel):
    job_description: str = Field(..., description="Job Description text to match against candidates")
    top_k: int = Field(default=10, ge=1, le=50, description="Top K candidates to retrieve")
    w_semantic: float = Field(default=0.50, ge=0.0, le=1.0)
    w_skill: float = Field(default=0.35, ge=0.0, le=1.0)
    w_exp: float = Field(default=0.15, ge=0.0, le=1.0)

class ExplainRequest(BaseModel):
    candidate_id: str
    job_description: str

class CompareRequest(BaseModel):
    candidate_id_a: str
    candidate_id_b: str
    job_description: Optional[str] = None

@router.post("/rank")
async def rank_candidates(req: RankRequest) -> Dict[str, Any]:
    """Rank all indexed candidate resumes against a given Job Description."""
    if not req.job_description.strip():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Job description cannot be empty.")
    
    ranked_results = ranker.rank_candidates(
        job_description=req.job_description,
        top_k=req.top_k,
        w_semantic=req.w_semantic,
        w_skill=req.w_skill,
        w_exp=req.w_exp
    )
    return {
        "job_description_length": len(req.job_description),
        "total_ranked": len(ranked_results),
        "results": ranked_results
    }

@router.post("/explain")
async def explain_candidate(req: ExplainRequest) -> Dict[str, Any]:
    """Generate an explainable candidate match report detailing strengths, gaps, and recommendations."""
    report = rag_engine.explain_candidate_match(req.candidate_id, req.job_description)
    if "error" in report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=report["error"])
    return report

@router.post("/compare")
async def compare_candidates(req: CompareRequest) -> Dict[str, Any]:
    """Side-by-side comparative analysis of Candidate A vs Candidate B."""
    report = rag_engine.compare_candidates(req.candidate_id_a, req.candidate_id_b, req.job_description)
    if "error" in report:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=report["error"])
    return report
