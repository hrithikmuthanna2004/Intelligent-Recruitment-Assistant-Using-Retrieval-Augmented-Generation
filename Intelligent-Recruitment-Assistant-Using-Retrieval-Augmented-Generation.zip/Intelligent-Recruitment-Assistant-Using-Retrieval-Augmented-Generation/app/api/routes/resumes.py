import os
import shutil
from pathlib import Path
from typing import List, Dict, Any
from fastapi import APIRouter, UploadFile, File, HTTPException, status
from app.config import settings
from app.core.document_loader import DocumentLoader
from app.core.vector_store import VectorStoreManager

router = APIRouter(prefix="/resumes", tags=["Resumes"])
vector_store = VectorStoreManager()

@router.post("/upload", status_code=status.HTTP_201_CREATED)
async def upload_resume(file: UploadFile = File(...)) -> Dict[str, Any]:
    """Upload a PDF or DOCX resume, parse its content & index it into ChromaDB."""
    filename = file.filename
    ext = Path(filename).suffix.lower()
    
    if ext not in [".pdf", ".docx", ".doc", ".txt"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported file extension. Only PDF, DOCX, and TXT files are supported."
        )

    # Save file to RAW_RESUMES_DIR
    save_path = os.path.join(settings.RAW_RESUMES_DIR, filename)
    with open(save_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        # Parse text and extract features
        parsed_data = DocumentLoader.parse_resume(save_path)
        
        # Index in ChromaDB
        doc_id = vector_store.add_resume(parsed_data)
        
        return {
            "message": "Resume uploaded and indexed successfully.",
            "doc_id": doc_id,
            "filename": filename,
            "candidate_name": parsed_data["candidate_name"],
            "email": parsed_data["email"],
            "skills": parsed_data["skills"],
            "experience_years": parsed_data["experience_years"],
            "education_level": parsed_data["education_level"]
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process and index resume: {str(e)}"
        )

@router.get("/", response_model=List[Dict[str, Any]])
async def list_resumes() -> List[Dict[str, Any]]:
    """List all indexed candidate resumes and metadata."""
    return vector_store.list_resumes()

@router.get("/{doc_id}")
async def get_resume(doc_id: str) -> Dict[str, Any]:
    """Get full parsed document details by ID."""
    resume = vector_store.get_resume_by_id(doc_id)
    if not resume:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    return resume

@router.delete("/{doc_id}")
async def delete_resume(doc_id: str) -> Dict[str, str]:
    """Delete candidate resume from database."""
    success = vector_store.delete_resume(doc_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found or could not be deleted")
    return {"message": f"Resume '{doc_id}' deleted successfully."}
