import os
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    APP_NAME: str = "Intelligent Recruitment Assistant RAG"
    VERSION: str = "1.0.0"
    DEBUG: bool = True

    # API Keys
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")

    # Embeddings & ChromaDB
    EMBEDDING_PROVIDER: str = os.getenv("EMBEDDING_PROVIDER", "sentence_transformers")
    EMBEDDING_MODEL_NAME: str = os.getenv("EMBEDDING_MODEL_NAME", "all-MiniLM-L6-v2")
    CHROMA_DB_DIR: str = str(BASE_DIR / "data" / "chroma_db")
    COLLECTION_NAME: str = "resumes"

    # Data directories
    RAW_RESUMES_DIR: str = str(BASE_DIR / "data" / "raw_resumes")
    JOB_DESCRIPTIONS_DIR: str = str(BASE_DIR / "data" / "job_descriptions")

    # FastAPI Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

# Ensure data directories exist
os.makedirs(settings.RAW_RESUMES_DIR, exist_ok=True)
os.makedirs(settings.JOB_DESCRIPTIONS_DIR, exist_ok=True)
os.makedirs(settings.CHROMA_DB_DIR, exist_ok=True)
