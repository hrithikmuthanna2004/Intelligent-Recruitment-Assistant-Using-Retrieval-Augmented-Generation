import os
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
import pypdf
import docx

# Comprehensive Skill Taxonomy covering Data Science, ML/AI, Software Engineering, DevOps, Cloud, DBs
SKILL_TAXONOMY = {
    # Data Science & Machine Learning
    "python": r"\bpython\b",
    "r": r"\br\b",
    "sql": r"\bsql\b",
    "machine learning": r"\bmachine\s+learning\b|\bml\b",
    "deep learning": r"\bdeep\s+learning\b|\bdl\b",
    "nlp": r"\bnlp\b|\bnatural\s+language\s+processing\b",
    "computer vision": r"\bcomputer\s+vision\b|\bcv\b",
    "tensorflow": r"\btensorflow\b",
    "pytorch": r"\bpytorch\b",
    "scikit-learn": r"\bscikit-learn\b|\bsklearn\b",
    "pandas": r"\bpandas\b",
    "numpy": r"\bnumpy\b",
    "scipy": r"\bscipy\b",
    "keras": r"\bkeras\b",
    "xgboost": r"\bxgboost\b",
    "lightgbm": r"\blightgbm\b",
    "transformers": r"\btransformers\b|\bhugging\s*face\b",
    "langchain": r"\blangchain\b",
    "rag": r"\brag\b|\bretrieval-augmented\s+generation\b",
    "llm": r"\bllm\b|\bllms\b|\blarge\s+language\s+models?\b",
    "vector database": r"\bvector\s+(database|store|db)\b|\bchromadb\b|\bfaiss\b|\bqdrant\b|\bpinecone\b",
    "generative ai": r"\bgenerative\s+ai\b|\bgenai\b",
    "data visualization": r"\bdata\s+visualization\b|\bmatplotlib\b|\bseaborn\b|\bplotly\b|\btableau\b|\bpower\s*bi\b",
    "feature engineering": r"\bfeature\s+engineering\b",
    "time series": r"\btime\s+series\b",
    "ab testing": r"\ba/b\s+testing\b|\bab\s+testing\b",
    "statistical modeling": r"\bstatistics?\b|\bstatistical\s+model(ing)?\b",

    # Cloud & DevOps
    "aws": r"\baws\b|\bamazon\s+web\s+services\b",
    "azure": r"\bazure\b|\bmicrosoft\s+azure\b",
    "gcp": r"\bgcp\b|\bgoogle\s+cloud\b",
    "docker": r"\bdocker\b",
    "kubernetes": r"\bkubernetes\b|\bk8s\b",
    "terraform": r"\bterraform\b",
    "ci/cd": r"\bci/cd\b|\bcontinuous\s+integration\b",
    "linux": r"\blinux\b",
    "bash": r"\bbash\b|\bshell\b",
    "git": r"\bgit\b|\bgithub\b|\bgitlab\b",

    # Software Engineering & Web
    "java": r"\bjava\b",
    "c++": r"\bc\+\+\b",
    "javascript": r"\bjavascript\b|\bjs\b",
    "typescript": r"\btypescript\b|\bts\b",
    "react": r"\breact(\.js)?\b",
    "node.js": r"\bnode(\.js)?\b",
    "fastapi": r"\bfastapi\b",
    "flask": r"\bflask\b",
    "django": r"\bdjango\b",
    "rest api": r"\brest(ful)?\s+api\b|\brest\s+apis?\b",
    "graphql": r"\bgraphql\b",
    "microservices": r"\bmicroservices\b",

    # Databases & Big Data
    "postgresql": r"\bpostgres(ql)?\b",
    "mysql": r"\bmysql\b",
    "mongodb": r"\bmongodb\b|\bmongo\b",
    "redis": r"\bredis\b",
    "spark": r"\bspark\b|\bpyspark\b",
    "hadoop": r"\bhadoop\b",
    "snowflake": r"\bsnowflake\b",
    "bigquery": r"\bbigquery\b",
    "kafka": r"\bkafka\b",

    # Soft Skills & Management
    "agile": r"\bagile\b|\bscrum\b",
    "communication": r"\bcommunication\b",
    "leadership": r"\bleadership\b",
    "problem solving": r"\bproblem\s+solving\b",
    "teamwork": r"\bteamwork\b|\bcollaboration\b"
}

class DocumentLoader:
    """Handles text extraction and NLP metadata parsing from PDF and DOCX resume files."""

    @staticmethod
    def extract_text_from_pdf(filepath: str) -> str:
        """Extract plain text from a PDF file."""
        text = ""
        try:
            reader = pypdf.PdfReader(filepath)
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
        except Exception as e:
            print(f"Error reading PDF {filepath}: {e}")
        return text.strip()

    @staticmethod
    def extract_text_from_docx(filepath: str) -> str:
        """Extract plain text from a DOCX file."""
        text = ""
        try:
            doc = docx.Document(filepath)
            for para in doc.paragraphs:
                if para.text:
                    text += para.text + "\n"
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + " "
                    text += "\n"
        except Exception as e:
            print(f"Error reading DOCX {filepath}: {e}")
        return text.strip()

    @classmethod
    def load_document(cls, filepath: str) -> str:
        """Load text based on file extension."""
        ext = Path(filepath).suffix.lower()
        if ext == ".pdf":
            return cls.extract_text_from_pdf(filepath)
        elif ext in [".docx", ".doc"]:
            return cls.extract_text_from_docx(filepath)
        elif ext in [".txt", ".md"]:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    @staticmethod
    def clean_text(text: str) -> str:
        """Clean and normalize extracted resume text."""
        # Replace multiple newlines or tabs with single spaces/newlines
        text = re.sub(r'[\r\t]+', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'[ ]{2,}', ' ', text)
        return text.strip()

    @staticmethod
    def extract_email(text: str) -> Optional[str]:
        """Extract candidate email using regex."""
        email_pattern = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+'
        match = re.search(email_pattern, text)
        return match.group(0) if match else None

    @staticmethod
    def extract_phone(text: str) -> Optional[str]:
        """Extract phone number using regex."""
        phone_pattern = r'(\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}'
        match = re.search(phone_pattern, text)
        return match.group(0) if match else None

    @staticmethod
    def extract_skills(text: str) -> List[str]:
        """Extract skills from text based on taxonomy matching."""
        found_skills = set()
        text_lower = text.lower()
        for skill_name, pattern in SKILL_TAXONOMY.items():
            if re.search(pattern, text_lower):
                found_skills.add(skill_name)
        return sorted(list(found_skills))

    @staticmethod
    def estimate_experience_years(text: str) -> float:
        """Estimate total years of experience from resume text."""
        # Pattern 1: explicit "X years of experience" or "X+ years"
        exp_pattern = r'(\d{1,2})\+?\s*(?:years?|yrs?)\s*(?:of)?\s*(?:experience|exp)?'
        matches = re.findall(exp_pattern, text.lower())
        if matches:
            years = [float(m) for m in matches if float(m) <= 35]
            if years:
                return max(years)

        # Pattern 2: Year ranges (e.g. 2018 - 2023 or 2020 - Present)
        year_ranges = re.findall(r'(20\d{2}|19\d{2})\s*[-–—to]+\s*(20\d{2}|19\d{2}|present|current)', text.lower())
        total_months = 0
        current_year = 2026
        for start, end in year_ranges:
            start_yr = int(start)
            end_yr = current_year if end in ['present', 'current'] else int(end)
            if end_yr >= start_yr:
                total_months += (end_yr - start_yr) * 12

        if total_months > 0:
            return round(total_months / 12.0, 1)

        return 1.0  # default baseline estimate

    @staticmethod
    def extract_education_level(text: str) -> str:
        """Identify highest education degree in resume."""
        text_lower = text.lower()
        if re.search(r'\b(phd|doctorate|doctor of philosophy)\b', text_lower):
            return "PhD / Doctorate"
        elif re.search(r'\b(msc|master|masters|m\.s\.|m\.tech|m\.e\.)\b', text_lower):
            return "Master's Degree"
        elif re.search(r'\b(bsc|bachelor|bachelors|b\.s\.|b\.tech|b\.e\.)\b', text_lower):
            return "Bachelor's Degree"
        elif re.search(r'\b(diploma|associate)\b', text_lower):
            return "Associate / Diploma"
        return "Not Specified"

    @staticmethod
    def extract_candidate_name(text: str, filename: str) -> str:
        """Infer candidate name from document header or filename."""
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        if lines:
            first_line = lines[0]
            # If line is short and looks like a name (no digits, not email/phone)
            if len(first_line) < 40 and not re.search(r'\d|@|http|resume|curriculum', first_line.lower()):
                return first_line.title()
        
        # Fallback to filename without extension
        clean_name = Path(filename).stem.replace('_', ' ').replace('-', ' ')
        clean_name = re.sub(r'resume|cv|\d+', '', clean_name, flags=re.IGNORECASE).strip()
        return clean_name.title() if clean_name else Path(filename).stem

    @classmethod
    def parse_resume(cls, filepath: str) -> Dict[str, Any]:
        """Comprehensive parsing entrypoint returning structured dictionary."""
        raw_text = cls.load_document(filepath)
        clean_txt = cls.clean_text(raw_text)
        filename = os.path.basename(filepath)

        candidate_name = cls.extract_candidate_name(clean_txt, filename)
        email = cls.extract_email(clean_txt)
        phone = cls.extract_phone(clean_txt)
        skills = cls.extract_skills(clean_txt)
        exp_years = cls.estimate_experience_years(clean_txt)
        education = cls.extract_education_level(clean_txt)

        return {
            "filename": filename,
            "filepath": str(Path(filepath).resolve()),
            "candidate_name": candidate_name,
            "email": email or "N/A",
            "phone": phone or "N/A",
            "skills": skills,
            "skill_count": len(skills),
            "experience_years": exp_years,
            "education_level": education,
            "raw_text": raw_text,
            "clean_text": clean_txt
        }
