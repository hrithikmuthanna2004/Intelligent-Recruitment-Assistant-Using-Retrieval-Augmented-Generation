import os
import numpy as np
from typing import List, Union
from app.config import settings

class EmbeddingManager:
    """Unified Embedding Manager supporting SentenceTransformers, Google Gemini, and OpenAI."""

    def __init__(self, provider: str = None, model_name: str = None):
        self.provider = provider or settings.EMBEDDING_PROVIDER
        self.model_name = model_name or settings.EMBEDDING_MODEL_NAME
        self.st_model = None
        self._init_model()

    def _init_model(self):
        """Initialize selected embedding engine."""
        if self.provider == "sentence_transformers":
            try:
                from sentence_transformers import SentenceTransformer
                self.st_model = SentenceTransformer(self.model_name)
            except Exception as e:
                print(f"SentenceTransformers init warning: {e}. Using deterministic fallback.")
                self.st_model = None
        elif self.provider == "gemini" and settings.GEMINI_API_KEY:
            try:
                from google import genai
                self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
            except Exception as e:
                print(f"Gemini client init error: {e}")
        elif self.provider == "openai" and settings.OPENAI_API_KEY:
            try:
                import openai
                self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            except Exception as e:
                print(f"OpenAI client init error: {e}")

    def embed_text(self, text: str) -> List[float]:
        """Embed a single text string into vector format."""
        return self.embed_documents([text])[0]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of text strings into vector format."""
        if not texts:
            return []

        # 1. SentenceTransformers (Local)
        if self.provider == "sentence_transformers" and self.st_model is not None:
            embeddings = self.st_model.encode(texts, convert_to_numpy=True)
            return embeddings.tolist()

        # 2. Google Gemini API
        elif self.provider == "gemini" and settings.GEMINI_API_KEY:
            try:
                results = []
                for txt in texts:
                    res = self.client.models.embed_content(
                        model="text-embedding-004",
                        contents=txt
                    )
                    results.append(res.embedding.values)
                return results
            except Exception as e:
                print(f"Gemini embedding error: {e}. Falling back to default embedding.")

        # 3. OpenAI API
        elif self.provider == "openai" and settings.OPENAI_API_KEY:
            try:
                import openai
                resp = self.client.embeddings.create(
                    input=texts,
                    model="text-embedding-3-small"
                )
                return [d.embedding for d in resp.data]
            except Exception as e:
                print(f"OpenAI embedding error: {e}. Falling back to default embedding.")

        # Fallback: Deterministic TF-IDF / Hash-based normalized 384-d vectors
        return [self._fallback_embedding(txt) for txt in texts]

    def _fallback_embedding(self, text: str, dim: int = 384) -> List[float]:
        """Deterministic 384-dimensional fallback vector based on word character hashing."""
        words = text.lower().split()
        vec = np.zeros(dim, dtype=np.float32)
        for i, word in enumerate(words):
            val = sum(ord(c) for c in word)
            idx = (val + i) % dim
            vec[idx] += 1.0
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec.tolist()
