from typing import List, Dict, Any, Tuple
from app.core.document_loader import DocumentLoader
from app.core.vector_store import VectorStoreManager

class CandidateRanker:
    """Computes Candidate Suitability Index (CSI) and ranks candidates against Job Descriptions."""

    def __init__(self, vector_store: VectorStoreManager = None):
        self.vector_store = vector_store or VectorStoreManager()

    @staticmethod
    def calculate_jaccard_skill_score(candidate_skills: List[str], jd_skills: List[str]) -> Tuple[float, List[str], List[str]]:
        """Calculate Jaccard skill match score and identify matching/missing skills."""
        cand_set = set(s.lower() for s in candidate_skills)
        jd_set = set(s.lower() for s in jd_skills)

        if not jd_set:
            return 1.0, list(cand_set), []

        matched_skills = sorted(list(cand_set.intersection(jd_set)))
        missing_skills = sorted(list(jd_set.difference(cand_set)))
        score = len(matched_skills) / len(jd_set)
        return round(score, 4), matched_skills, missing_skills

    @staticmethod
    def calculate_experience_score(cand_exp: float, target_exp: float) -> float:
        """Calculate experience alignment ratio."""
        if target_exp <= 0:
            return 1.0
        score = min(1.0, cand_exp / target_exp)
        return round(score, 4)

    def rank_candidates(
        self,
        job_description: str,
        top_k: int = 10,
        w_semantic: float = 0.50,
        w_skill: float = 0.35,
        w_exp: float = 0.15
    ) -> List[Dict[str, Any]]:
        """Rank all indexed candidates against a Job Description using hybrid CSI algorithm."""
        # 1. Parse Job Description
        jd_skills = DocumentLoader.extract_skills(job_description)
        target_exp = DocumentLoader.estimate_experience_years(job_description)

        # 2. Retrieve candidate pool via vector similarity (fetch broader candidate pool for re-ranking)
        candidates = self.vector_store.search_similar(query_text=job_description, top_k=100)

        ranked = []
        for cand in candidates:
            cand_skills = cand.get("skills", [])
            cand_exp = cand.get("experience_years", 0.0)

            # Sub-scores
            sim_score = cand.get("similarity_score", 0.0)
            skill_score, matched_skills, missing_skills = self.calculate_jaccard_skill_score(cand_skills, jd_skills)
            exp_score = self.calculate_experience_score(cand_exp, target_exp)

            # Composite Suitability Index
            csi = (w_semantic * sim_score) + (w_skill * skill_score) + (w_exp * exp_score)
            csi_percentage = round(csi * 100, 2)

            ranked.append({
                "id": cand["id"],
                "candidate_name": cand["candidate_name"],
                "filename": cand["filename"],
                "email": cand["email"],
                "phone": cand["phone"],
                "csi_score": csi_percentage,
                "csi_raw": round(csi, 4),
                "semantic_similarity": round(sim_score * 100, 2),
                "skill_match_score": round(skill_score * 100, 2),
                "experience_score": round(exp_score * 100, 2),
                "candidate_experience": cand_exp,
                "target_experience": target_exp,
                "candidate_skills": cand_skills,
                "jd_skills": jd_skills,
                "matched_skills": matched_skills,
                "missing_skills": missing_skills,
                "education_level": cand["education_level"],
                "raw_text": cand["raw_text"]
            })

        # Sort descending by CSI score
        ranked.sort(key=lambda x: x["csi_score"], reverse=True)
        
        # Add rank position index
        for idx, item in enumerate(ranked):
            item["rank"] = idx + 1

        return ranked[:top_k]
