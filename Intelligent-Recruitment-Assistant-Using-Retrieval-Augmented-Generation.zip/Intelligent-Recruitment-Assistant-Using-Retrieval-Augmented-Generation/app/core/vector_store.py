import os
import json
import chromadb
from chromadb.config import Settings as ChromaSettings
from typing import List, Dict, Any, Optional
from app.config import settings
from app.core.embeddings import EmbeddingManager

class VectorStoreManager:
    """Manages ChromaDB vector indexing and retrieval for candidate resumes."""

    def __init__(self, db_dir: str = None, collection_name: str = None):
        self.db_dir = db_dir or settings.CHROMA_DB_DIR
        self.collection_name = collection_name or settings.COLLECTION_NAME
        self.embedding_manager = EmbeddingManager()
        
        # Initialize persistent ChromaDB client
        self.client = chromadb.PersistentClient(
            path=self.db_dir,
            settings=ChromaSettings(allow_reset=True)
        )
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"description": "Candidate Resumes Collection"}
        )

    def add_resume(self, parsed_resume: Dict[str, Any]) -> str:
        """Index a parsed resume into ChromaDB."""
        doc_id = f"resume_{parsed_resume['filename']}"
        raw_text = parsed_resume.get("raw_text", "")
        skills_str = ", ".join(parsed_resume.get("skills", []))

        # Flatten metadata for ChromaDB compatibility (primitive types only)
        metadata = {
            "candidate_name": str(parsed_resume.get("candidate_name", "Unknown")),
            "filename": str(parsed_resume.get("filename", "")),
            "email": str(parsed_resume.get("email", "")),
            "phone": str(parsed_resume.get("phone", "")),
            "skills": skills_str,
            "skill_count": int(parsed_resume.get("skill_count", 0)),
            "experience_years": float(parsed_resume.get("experience_years", 0.0)),
            "education_level": str(parsed_resume.get("education_level", "Unspecified")),
            "filepath": str(parsed_resume.get("filepath", ""))
        }

        # Generate embedding for the full resume text
        embedding = self.embedding_manager.embed_text(raw_text)

        # Upsert into ChromaDB collection
        self.collection.upsert(
            ids=[doc_id],
            embeddings=[embedding],
            documents=[raw_text],
            metadatas=[metadata]
        )
        return doc_id

    def list_resumes(self) -> List[Dict[str, Any]]:
        """List all indexed resumes with metadata."""
        data = self.collection.get(include=["metadatas", "documents"])
        resumes = []
        if data and data.get("ids"):
            for i, doc_id in enumerate(data["ids"]):
                meta = data["metadatas"][i]
                doc_text = data["documents"][i] if data.get("documents") else ""
                skills_list = [s.strip() for s in meta.get("skills", "").split(",") if s.strip()]
                resumes.append({
                    "id": doc_id,
                    "candidate_name": meta.get("candidate_name"),
                    "filename": meta.get("filename"),
                    "email": meta.get("email"),
                    "phone": meta.get("phone"),
                    "skills": skills_list,
                    "skill_count": meta.get("skill_count", len(skills_list)),
                    "experience_years": meta.get("experience_years", 0.0),
                    "education_level": meta.get("education_level"),
                    "filepath": meta.get("filepath"),
                    "text_preview": doc_text[:300] + "..." if len(doc_text) > 300 else doc_text
                })
        return resumes

    def get_resume_by_id(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve complete resume document and metadata by ID."""
        data = self.collection.get(ids=[doc_id], include=["metadatas", "documents"])
        if data and data.get("ids") and len(data["ids"]) > 0:
            meta = data["metadatas"][0]
            doc_text = data["documents"][0]
            skills_list = [s.strip() for s in meta.get("skills", "").split(",") if s.strip()]
            return {
                "id": doc_id,
                "candidate_name": meta.get("candidate_name"),
                "filename": meta.get("filename"),
                "email": meta.get("email"),
                "phone": meta.get("phone"),
                "skills": skills_list,
                "skill_count": meta.get("skill_count", len(skills_list)),
                "experience_years": meta.get("experience_years", 0.0),
                "education_level": meta.get("education_level"),
                "filepath": meta.get("filepath"),
                "raw_text": doc_text
            }
        return None

    def search_similar(self, query_text: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Semantic search against candidate database."""
        query_embedding = self.embedding_manager.embed_text(query_text)
        
        count = self.collection.count()
        if count == 0:
            return []

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, count),
            include=["metadatas", "documents", "distances"]
        )

        candidates = []
        if results and results.get("ids") and len(results["ids"]) > 0:
            ids = results["ids"][0]
            metadatas = results["metadatas"][0]
            documents = results["documents"][0]
            distances = results["distances"][0]

            for i in range(len(ids)):
                dist = distances[i]
                # Convert L2 distance or Cosine distance to similarity score in [0, 1]
                sim_score = max(0.0, min(1.0, 1.0 - (dist / 2.0)))
                meta = metadatas[i]
                skills_list = [s.strip() for s in meta.get("skills", "").split(",") if s.strip()]
                
                candidates.append({
                    "id": ids[i],
                    "candidate_name": meta.get("candidate_name"),
                    "filename": meta.get("filename"),
                    "email": meta.get("email"),
                    "phone": meta.get("phone"),
                    "skills": skills_list,
                    "experience_years": meta.get("experience_years", 0.0),
                    "education_level": meta.get("education_level"),
                    "similarity_score": round(sim_score, 4),
                    "raw_text": documents[i]
                })

        return candidates

    def delete_resume(self, doc_id: str) -> bool:
        """Delete a resume from vector store."""
        try:
            self.collection.delete(ids=[doc_id])
            return True
        except Exception as e:
            print(f"Error deleting doc {doc_id}: {e}")
            return False

    def reset_collection(self):
        """Reset entire vector collection."""
        self.client.delete_collection(name=self.collection_name)
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"description": "Candidate Resumes Collection"}
        )
