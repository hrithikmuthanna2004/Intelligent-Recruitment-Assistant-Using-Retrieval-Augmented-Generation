#!/bin/bash
# AWS EC2 & S3 Deployment Guide Script for Intelligent Recruitment Assistant

set -e

echo "=========================================================="
echo " AWS EC2 & S3 Deployment Automation Script"
echo " Project: Intelligent Recruitment Assistant (RAG)"
echo "=========================================================="

# Step 1: Update System Packages & Install Docker
echo "[1/4] Updating system packages & installing Docker..."
sudo apt-get update -y
sudo apt-get install -y docker.io docker-compose git awscli

# Step 2: Enable Docker Service
echo "[2/4] Enabling Docker service..."
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER

# Step 3: Configure AWS S3 Storage for Resumes (Optional)
S3_BUCKET_NAME="recruitment-assistant-resumes-$(date +%s)"
echo "[3/4] Creating AWS S3 bucket: $S3_BUCKET_NAME..."
aws s3 mb s3://$S3_BUCKET_NAME --region us-east-1 || true

# Sync local resumes to S3
if [ -d "./data/raw_resumes" ]; then
    echo "Syncing local resumes to AWS S3 bucket..."
    aws s3 sync ./data/raw_resumes s3://$S3_BUCKET_NAME/raw_resumes/
fi

# Step 4: Build & Launch Containerized Stack
echo "[4/4] Launching FastAPI & Streamlit services via Docker Compose..."
docker-compose up -d --build

echo "=========================================================="
echo " DEPLOYMENT COMPLETE!"
echo " FastAPI Backend API:  http://<EC2-PUBLIC-IP>:8000/docs"
echo " Streamlit Dashboard:  http://<EC2-PUBLIC-IP>:8501"
echo "=========================================================="
