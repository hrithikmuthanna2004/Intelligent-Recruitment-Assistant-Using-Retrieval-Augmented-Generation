import os
import sys
import numpy as np

# Add project root directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.vector_store import VectorStoreManager
from app.core.ranker import CandidateRanker

# Evaluation Benchmark Benchmark Test Queries with Expected Ground Truth Candidates
BENCHMARK_EVAL_QUERIES = [
    {
        "query": "Find candidates with Python, Machine Learning, PyTorch, and RAG experience",
        "expected_top_candidate": "Alex Morgan"
    },
    {
        "query": "Which applicants have PhD or research experience in Natural Language Processing and Transformers?",
        "expected_top_candidate": "Priya Sharma"
    },
    {
        "query": "Senior Cloud DevOps Engineer with AWS, Terraform, Docker, and Kubernetes skills",
        "expected_top_candidate": "Marcus Vance"
    },
    {
        "query": "Full Stack developer proficient in React, TypeScript, FastAPI, and JavaScript",
        "expected_top_candidate": "Elena Rostova"
    },
    {
        "query": "Machine Learning Engineer with Computer Vision, OpenCV, and C++ experience",
        "expected_top_candidate": "David Chen"
    }
]

def evaluate_retrieval_system(top_k: int = 3):
    print("=" * 60)
    print("MSc DATA SCIENCE RAG RETRIEVAL SYSTEM EVALUATION")
    print("=" * 60)

    ranker = CandidateRanker()
    
    reciprocal_ranks = []
    hits = 0
    precisions = []

    for item in BENCHMARK_EVAL_QUERIES:
        query = item["query"]
        expected = item["expected_top_candidate"]

        ranked = ranker.rank_candidates(
            job_description=query,
            top_k=top_k,
            w_semantic=0.30,
            w_skill=0.55,
            w_exp=0.15
        )
        retrieved_names = [r["candidate_name"] for r in ranked]

        # Calculate Rank of Expected Candidate
        rank = -1
        for i, name in enumerate(retrieved_names):
            if expected.lower() in name.lower():
                rank = i + 1
                break

        if rank > 0:
            hits += 1
            rr = 1.0 / rank
            precision = 1.0 / top_k  # 1 relevant candidate retrieved in top-k
        else:
            rr = 0.0
            precision = 0.0

        reciprocal_ranks.append(rr)
        precisions.append(precision)

        print(f"\nQuery: '{query}'")
        print(f"  Expected Top Candidate: {expected}")
        print(f"  Retrieved Rank #1:     {retrieved_names[0] if retrieved_names else 'None'}")
        print(f"  Expected Rank:         {rank if rank > 0 else 'Not in Top ' + str(top_k)}")
        print(f"  Reciprocal Rank (RR):  {round(rr, 4)}")

    mrr = np.mean(reciprocal_ranks)
    hit_rate = hits / len(BENCHMARK_EVAL_QUERIES)
    avg_precision = np.mean(precisions)

    print("\n" + "=" * 60)
    print("AGGREGATED RETRIEVAL EVALUATION RESULTS")
    print("=" * 60)
    print(f"Total Benchmark Queries Evaluated: {len(BENCHMARK_EVAL_QUERIES)}")
    print(f"Top-K Metric Cutoff:               K = {top_k}")
    print(f"Hit Rate @ K={top_k}:                     {round(hit_rate * 100, 2)}%")
    print(f"Mean Reciprocal Rank (MRR):        {round(mrr, 4)}")
    print(f"Mean Precision @ K={top_k}:               {round(avg_precision * 100, 2)}%")
    print("=" * 60)

if __name__ == "__main__":
    evaluate_retrieval_system(top_k=3)
