import os
import sys
from pathlib import Path

# Add project root directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings
from app.core.document_loader import DocumentLoader
from app.core.vector_store import VectorStoreManager

# Ensure target directories exist
os.makedirs(settings.RAW_RESUMES_DIR, exist_ok=True)
os.makedirs(settings.JOB_DESCRIPTIONS_DIR, exist_ok=True)

SAMPLE_RESUMES = [
    {
        "filename": "Alex_Morgan_Data_Scientist.txt",
        "content": """Alex Morgan
Email: alex.morgan@email.com | Phone: +1-555-019-2834 | San Francisco, CA

SUMMARY
Passionate Senior Data Scientist with 5+ years of hands-on experience developing end-to-end Machine Learning, Deep Learning, and RAG architectures. Expert in Python, SQL, PyTorch, LangChain, and ChromaDB vector search. Proven track record of deploying LLM applications and FastAPI backend microservices to AWS.

EDUCATION
Master of Science in Data Science | Stanford University (2019 - 2021)
Bachelor of Science in Computer Science | UC Berkeley (2015 - 2019)

EXPERIENCE
Lead Data Scientist | Nexus AI Labs (2021 - Present)
• Built a Retrieval-Augmented Generation (RAG) system using LangChain, ChromaDB, and PyTorch, improving semantic search accuracy by 35%.
• Fine-tuned Large Language Models (LLMs) and sentence-transformers for custom entity extraction and question-answering pipelines.
• Architected scalable FastAPI REST APIs integrated with PostgreSQL and Redis, deployed on AWS EC2 and Docker containers.
• Spearheaded feature engineering and A/B testing frameworks for predictive ML pipelines handling 50M+ daily events.

Data Science Intern | TechCorp Inc (2020 - 2021)
• Developed Scikit-Learn classification algorithms and Pandas data cleaning pipelines for customer churn forecasting.
• Created interactive Tableau and Data Visualization dashboards for C-suite executive reporting.

TECHNICAL SKILLS
Languages: Python, SQL, R, Bash
ML/AI Frameworks: Machine Learning, Deep Learning, PyTorch, TensorFlow, Scikit-Learn, Pandas, NumPy, XGBoost, LangChain, RAG, LLM, Vector Database, Transformers
Cloud & Tools: AWS, Docker, FastAPI, PostgreSQL, Git, CI/CD
"""
    },
    {
        "filename": "Priya_Sharma_NLP_Specialist.txt",
        "content": """Dr. Priya Sharma
Email: priya.sharma@research.org | Phone: +1-555-482-9102 | Boston, MA

SUMMARY
AI Research Scientist and NLP Specialist with a PhD in Computational Linguistics and 4 years of industry experience. Specialized in Natural Language Processing, HuggingFace Transformers, Generative AI, Large Language Models, and PyTorch.

EDUCATION
PhD in Computer Science (NLP & AI) | MIT (2018 - 2022)
Master of Science in Artificial Intelligence | Carnegie Mellon University (2016 - 2018)

EXPERIENCE
Senior NLP Research Scientist | Cognition Research Lab (2022 - Present)
• Published research on domain adaptation for HuggingFace Transformers and zero-shot NLP sentiment classifiers.
• Implemented LangChain and Generative AI pipelines for automated document summarization and retrieval.
• Utilized Python, PyTorch, Scikit-Learn, and FAISS for high-dimensional vector embeddings and semantic search.

AI Research Assistant | MIT AI Lab (2018 - 2022)
• Authored 5 peer-reviewed papers on neural machine translation and contextual word embeddings.
• Taught graduate courses in Python, Machine Learning, and Natural Language Processing.

TECHNICAL SKILLS
Core: NLP, Natural Language Processing, Generative AI, LLM, Transformers, PyTorch, Python, Scikit-Learn, R, LangChain, Vector Database, Computer Vision
"""
    },
    {
        "filename": "Marcus_Vance_DevOps_Engineer.txt",
        "content": """Marcus Vance
Email: marcus.vance@cloudtech.com | Phone: +1-555-839-1049 | Seattle, WA

SUMMARY
Senior Cloud DevOps & MLOps Engineer with 6+ years of experience designing resilient cloud infrastructure on AWS, GCP, and Azure. Expertise in Docker, Kubernetes, Terraform, CI/CD pipelines, Linux, Python, and automated model deployment.

EDUCATION
Bachelor of Science in Information Technology | University of Washington (2014 - 2018)

EXPERIENCE
Lead Infrastructure & DevOps Engineer | CloudScale Systems (2020 - Present)
• Automated enterprise AWS cloud infrastructure using Terraform, Docker, and Kubernetes (EKS), reducing deployment downtime by 80%.
• Designed robust CI/CD pipelines with Git, GitLab CI, and Jenkins for seamless REST API and microservices deployment.
• Implemented monitoring and logging infrastructure using Prometheus, Grafana, and Linux shell scripts.

Cloud System Administrator | TechLogix (2018 - 2020)
• Managed Linux server clusters, MySQL database backups, and Redis caching layers.
• Scripted automated infrastructure monitoring using Python and Bash.

TECHNICAL SKILLS
Cloud & DevOps: AWS, Azure, GCP, Docker, Kubernetes, Terraform, CI/CD, Linux, Bash, Git, Microservices, Python, SQL, REST API
"""
    },
    {
        "filename": "Elena_Rostova_FullStack_Developer.txt",
        "content": """Elena Rostova
Email: elena.rostova@dev.io | Phone: +1-555-721-3094 | New York, NY

SUMMARY
Full Stack Web & AI Software Engineer with 3+ years of experience constructing modern web applications using Python, FastAPI, Django, React, TypeScript, JavaScript, PostgreSQL, and Docker.

EDUCATION
Master of Science in Software Engineering | NYU (2020 - 2022)
Bachelor of Science in Applied Mathematics | Columbia University (2016 - 2020)

EXPERIENCE
Full Stack Software Developer | WebCraft Studios (2022 - Present)
• Built responsive single-page web applications using React, TypeScript, JavaScript, and Tailwind CSS.
• Developed high-performance backend REST APIs in Python using FastAPI and Django connected to PostgreSQL and MongoDB.
• Integrated OpenAI and vector search APIs into web frontend dashboards, enabling real-time AI search.
• Containerized application services using Docker and configured CI/CD deployment pipelines on AWS.

TECHNICAL SKILLS
Frontend: React, TypeScript, JavaScript, HTML5, CSS3, Node.js
Backend: Python, FastAPI, Django, Flask, REST API, GraphQL, PostgreSQL, MongoDB, Docker, Git, Agile
"""
    },
    {
        "filename": "David_Chen_ML_Engineer.txt",
        "content": """David Chen
Email: david.chen@aiengine.com | Phone: +1-555-902-1134 | Austin, TX

SUMMARY
Machine Learning Engineer with 4 years of experience delivering computer vision, deep learning, and predictive modeling solutions. Proficient in Python, C++, TensorFlow, OpenCV, Docker, and AWS.

EDUCATION
Master of Science in Computer Science | UT Austin (2018 - 2020)
Bachelor of Engineering | Illinois Tech (2014 - 2018)

EXPERIENCE
Machine Learning Engineer | Visionary AI (2020 - Present)
• Engineered real-time Computer Vision detection models using OpenCV, PyTorch, and TensorFlow deployed on edge devices.
• Built data ingestion pipelines using Python, SQL, Spark, and Docker.
• Reduced model inference latency by 45% using TensorRT optimization and C++ integration.

TECHNICAL SKILLS
Skills: Python, C++, Machine Learning, Deep Learning, Computer Vision, TensorFlow, PyTorch, Scikit-Learn, Docker, AWS, SQL, Spark
"""
    }
]

SAMPLE_JOB_DESCRIPTIONS = [
    {
        "filename": "JD_Data_Scientist.txt",
        "content": """Job Title: Senior Data Scientist (ML & RAG)
Location: Remote / San Francisco
Required Experience: 3+ years

Job Responsibilities:
We are seeking an ambitious Senior Data Scientist to spearhead our AI & NLP initiatives. You will design, build, and deploy state-of-the-art Retrieval-Augmented Generation (RAG) systems, vector database search solutions, and Large Language Model applications.

Key Requirements:
• 3+ years of professional experience in Data Science, Machine Learning, and Deep Learning.
• Strong proficiency in Python, SQL, and PyTorch / TensorFlow.
• Hands-on experience with NLP, HuggingFace Transformers, LangChain, and Vector Databases (ChromaDB / FAISS).
• Demonstrated experience building and deploying FastAPI REST APIs using Docker and AWS.
• Solid background in statistical modeling, feature engineering, and data visualization.
• Master's or Bachelor's degree in Data Science, Computer Science, or quantitative discipline.
"""
    },
    {
        "filename": "JD_DevOps_Engineer.txt",
        "content": """Job Title: Cloud DevOps & MLOps Engineer
Location: Seattle, WA / Hybrid
Required Experience: 4+ years

Job Responsibilities:
Looking for an experienced Cloud DevOps Engineer to manage cloud infrastructure, build CI/CD automation pipelines, and optimize containerized microservices deployments for AI workloads.

Key Requirements:
• 4+ years of hands-on experience in AWS cloud infrastructure management.
• Expertise in Docker, Kubernetes (EKS), Terraform, and CI/CD pipelines.
• Strong scripting skills in Python, Bash, and Linux system administration.
• Solid understanding of microservices architecture, REST APIs, and database administration (PostgreSQL / MySQL).
"""
    }
]

def generate_and_index():
    print("Generating sample resumes and job descriptions...")
    vector_store = VectorStoreManager()

    # 1. Generate Resume Files & Index
    for sample in SAMPLE_RESUMES:
        filepath = os.path.join(settings.RAW_RESUMES_DIR, sample["filename"])
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(sample["content"].strip())
        
        print(f"Parsing and indexing: {sample['filename']}")
        parsed = DocumentLoader.parse_resume(filepath)
        doc_id = vector_store.add_resume(parsed)
        print(f"Indexed as doc_id: {doc_id} (Candidate: {parsed['candidate_name']})")

    # 2. Generate Job Descriptions
    for jd in SAMPLE_JOB_DESCRIPTIONS:
        filepath = os.path.join(settings.JOB_DESCRIPTIONS_DIR, jd["filename"])
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(jd["content"].strip())
        print(f"Saved Job Description: {jd['filename']}")

    total_count = vector_store.collection.count()
    print(f"\nDone! Successfully generated sample files and indexed {total_count} candidate profiles into ChromaDB.")

if __name__ == "__main__":
    generate_and_index()
