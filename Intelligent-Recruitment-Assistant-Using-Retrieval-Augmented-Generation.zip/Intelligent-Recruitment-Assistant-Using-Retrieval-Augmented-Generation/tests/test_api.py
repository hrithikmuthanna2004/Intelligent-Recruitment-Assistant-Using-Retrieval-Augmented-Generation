import pytest
from fastapi.testclient import TestClient
from app.api.main import app

client = TestClient(app)

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "total_resumes_indexed" in data

def test_list_resumes_endpoint():
    response = client.get("/api/v1/resumes/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_rank_endpoint():
    payload = {
        "job_description": "Looking for Data Scientist with Python and ML experience",
        "top_k": 5
    }
    response = client.post("/api/v1/matching/rank", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "results" in data

def test_chat_query_endpoint():
    payload = {
        "query": "Find candidates with Python experience",
        "top_k": 3
    }
    response = client.post("/api/v1/chat/query", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "answer" in data
