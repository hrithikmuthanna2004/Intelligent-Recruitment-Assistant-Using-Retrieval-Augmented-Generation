import pytest
from app.core.document_loader import DocumentLoader

SAMPLE_TEXT = """
Jane Doe
Email: jane.doe@example.com | Phone: 555-123-4567

SUMMARY
Senior Data Scientist with 4 years of experience specializing in Python, SQL, Machine Learning, Deep Learning, PyTorch, and RAG architectures.

EDUCATION
Master of Science in Data Science | NYU (2020 - 2022)

SKILLS
Python, SQL, PyTorch, Scikit-Learn, Docker, AWS, FastAPI, Machine Learning, RAG, ChromaDB
"""

def test_extract_email():
    email = DocumentLoader.extract_email(SAMPLE_TEXT)
    assert email == "jane.doe@example.com"

def test_extract_phone():
    phone = DocumentLoader.extract_phone(SAMPLE_TEXT)
    assert phone is not None
    assert "555-123-4567" in phone

def test_extract_skills():
    skills = DocumentLoader.extract_skills(SAMPLE_TEXT)
    assert "python" in skills
    assert "sql" in skills
    assert "pytorch" in skills
    assert "rag" in skills
    assert "machine learning" in skills

def test_estimate_experience_years():
    exp = DocumentLoader.estimate_experience_years(SAMPLE_TEXT)
    assert exp == 4.0

def test_extract_education_level():
    edu = DocumentLoader.extract_education_level(SAMPLE_TEXT)
    assert edu == "Master's Degree"
