import pytest
from app.core.ranker import CandidateRanker

def test_jaccard_skill_score():
    cand_skills = ["python", "sql", "aws", "docker"]
    jd_skills = ["python", "sql", "aws", "kubernetes"]

    score, matched, missing = CandidateRanker.calculate_jaccard_skill_score(cand_skills, jd_skills)
    
    assert score == 0.75  # 3 of 4 matched
    assert "python" in matched
    assert "sql" in matched
    assert "aws" in matched
    assert "kubernetes" in missing

def test_experience_score():
    score1 = CandidateRanker.calculate_experience_score(cand_exp=4.0, target_exp=3.0)
    assert score1 == 1.0  # Max capped at 1.0

    score2 = CandidateRanker.calculate_experience_score(cand_exp=2.0, target_exp=4.0)
    assert score2 == 0.5
