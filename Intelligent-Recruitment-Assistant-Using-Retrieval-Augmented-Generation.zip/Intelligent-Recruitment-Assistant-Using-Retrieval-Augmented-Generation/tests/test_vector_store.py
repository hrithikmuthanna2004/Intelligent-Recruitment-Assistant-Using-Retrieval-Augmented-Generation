import pytest
import shutil
import tempfile
from app.core.vector_store import VectorStoreManager

@pytest.fixture
def temp_vector_store():
    temp_dir = tempfile.mkdtemp()
    store = VectorStoreManager(db_dir=temp_dir, collection_name="test_collection")
    yield store
    shutil.rmtree(temp_dir, ignore_errors=True)

def test_add_and_retrieve_resume(temp_vector_store):
    parsed_data = {
        "filename": "test_resume.txt",
        "filepath": "/tmp/test_resume.txt",
        "candidate_name": "Test Candidate",
        "email": "test@candidate.com",
        "phone": "555-000-1111",
        "skills": ["python", "sql", "aws"],
        "skill_count": 3,
        "experience_years": 3.0,
        "education_level": "Bachelor's Degree",
        "raw_text": "Test candidate with Python, SQL, and AWS experience."
    }

    doc_id = temp_vector_store.add_resume(parsed_data)
    assert doc_id == "resume_test_resume.txt"

    resumes = temp_vector_store.list_resumes()
    assert len(resumes) == 1
    assert resumes[0]["candidate_name"] == "Test Candidate"

    retrieved = temp_vector_store.get_resume_by_id(doc_id)
    assert retrieved is not None
    assert retrieved["email"] == "test@candidate.com"

def test_search_similar(temp_vector_store):
    parsed1 = {
        "filename": "devops.txt",
        "candidate_name": "Bob DevOps",
        "email": "bob@devops.com",
        "phone": "555-111-2222",
        "skills": ["aws", "docker", "kubernetes"],
        "skill_count": 3,
        "experience_years": 5.0,
        "education_level": "Bachelor's Degree",
        "raw_text": "Experienced DevOps Engineer proficient in AWS, Docker, and Kubernetes."
    }
    temp_vector_store.add_resume(parsed1)

    results = temp_vector_store.search_similar("AWS Docker Cloud Engineer", top_k=1)
    assert len(results) == 1
    assert results[0]["candidate_name"] == "Bob DevOps"
